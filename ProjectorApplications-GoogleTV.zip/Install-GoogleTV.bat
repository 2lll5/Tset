@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "PACKAGE=com.projectorapplications.receiver"
set "ACTIVITY=com.projectorapplications.receiver/.MainActivity"
set "APK=%~dp0app-debug.apk"

call :find_adb
if not defined ADB (
  echo [ERROR] adb.exe was not found.
  echo Install Android platform-tools or add adb.exe to PATH.
  pause
  exit /b 1
)

if not exist "%APK%" (
  echo [ERROR] app-debug.apk was not found next to this installer.
  pause
  exit /b 1
)

set "DEVICE_COUNT=0"
set "DEVICE="
for /f "skip=1 tokens=1,2" %%A in ('"%ADB%" devices 2^>nul') do (
  if "%%B"=="device" (
    set /a DEVICE_COUNT+=1
    set "DEVICE=%%A"
  )
)

if "%DEVICE_COUNT%"=="0" (
  echo [ERROR] No authorized ADB device is connected.
  echo Connect to the Google TV with adb first, then run this installer again.
  pause
  exit /b 1
)

if not "%DEVICE_COUNT%"=="1" (
  echo Multiple ADB devices are connected:
  "%ADB%" devices
  echo.
  set /p "DEVICE=Enter the Google TV device serial exactly as shown above: "
  if not defined DEVICE (
    echo [ERROR] No device selected.
    pause
    exit /b 1
  )
)

echo Using ADB: "%ADB%"
echo Target: %DEVICE%
echo.
echo Stopping old receiver...
"%ADB%" -s "%DEVICE%" shell am force-stop %PACKAGE% >nul 2>nul

echo Removing old receiver for a clean update...
"%ADB%" -s "%DEVICE%" uninstall %PACKAGE% >nul 2>nul

echo Installing new receiver...
"%ADB%" -s "%DEVICE%" install "%APK%"
if errorlevel 1 (
  echo.
  echo [ERROR] APK installation failed.
  pause
  exit /b 1
)

echo Starting ProjectorApplications on Google TV...
"%ADB%" -s "%DEVICE%" shell am start -n %ACTIVITY%
if errorlevel 1 (
  echo.
  echo [ERROR] APK installed, but the receiver could not be started automatically.
  pause
  exit /b 1
)

echo.
echo Clean update completed successfully.
pause
exit /b 0

:find_adb
set "ADB="
for /f "delims=" %%A in ('where adb.exe 2^>nul') do if not defined ADB set "ADB=%%A"
if not defined ADB if exist "%USERPROFILE%\Downloads\platform-tools-latest-windows\platform-tools\adb.exe" set "ADB=%USERPROFILE%\Downloads\platform-tools-latest-windows\platform-tools\adb.exe"
if not defined ADB if exist "%USERPROFILE%\Downloads\platform-tools\adb.exe" set "ADB=%USERPROFILE%\Downloads\platform-tools\adb.exe"
exit /b 0
